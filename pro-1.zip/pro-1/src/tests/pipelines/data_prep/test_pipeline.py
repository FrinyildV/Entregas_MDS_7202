"""
This is a boilerplate test file for pipeline 'data_prep'
generated using Kedro 0.18.11.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
